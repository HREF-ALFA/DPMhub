<?php


    $host = localhost;
    $dbname = dolibarr;
    $user = root;
    $pass = root;
    
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    }catch( PDOException $e) {
        echo "Error Connection: " . $e->getMessage();
    }


    //explosion
    	$consulta="SELECT * from llx_commande_fournisseurdet group by (fk_commande)";
    	$result=$conn->prepare($consulta) or $myVar=true;
		$result->execute();
		$num_record=$result->rowCount();

		$i=0;
        $array;
        while($row = $result->fetch(PDO::FETCH_ASSOC)) {
              
             $array[$i]=$row['fk_commande'];
              $i++;

        }

        for($i=1; $i<=$num_record; $i++){
           
        $consulta2="SELECT * from llx_commande_fournisseurdet where fk_commande = {0}";
        $questionsSQL= str_replace("{0}", $array[$i-1], $consulta2);
        $myRsRes=$conn->prepare($questionsSQL);
        $myRsRes->execute();
        $num_record2=$myRsRes->rowCount();
        echo $num_record2.'--';

        }


          

        
		









?>